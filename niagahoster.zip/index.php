<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" href="asset/css/style.css">

    <title>Niagahoster</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-light border-bottom navigation">
  <div class="container">
    <a class="navbar-brand" href="#">
      <img src="asset/img/logo.png" alt="Niagahoster" height="60">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Hosting</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Domain</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Server</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Website</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Afiliasi</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Promo</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Pembayaran</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Review</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Kontak</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Blog</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<section class="mt-5 mb-5 pb-5 border-bottom">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h1>PHP Hosting</h1>
        <h2>Cepat, Handal, Penuh dengan modul PHP yang anda butuhkan</h2>
        <ul>
          <li>Solusi PHP untuk performa query yang lebih cepat.</li>
          <li>Konsumsi memori yang lebih rendah.</li>
          <li>Support PHP 5.3, PHP 5.4, PHP 5.5, PHP 5.6, PHP 7.</li>
          <li>Fitur enkripsi IonCube dan Zend Guard Loaders.</li>

        </ul>
      </div>
      <div class="col-md-6">
        <img src="asset/svg/illustration banner PHP hosting-01.svg" alt="">
      </div>
    </div>
  </div>
</section>
<section class="mt-5 pt-2 mb-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-3" >
        <div class="frame-image-center mb-3">
          <img src="asset/svg/illustration-banner-PHP-zenguard01.svg" alt="" >
        </div>
        <h5 class="text-center">PHP Zend Guard Loader</h5>
      </div>
      <div class="col-md-3">
        <div class="frame-image-center mb-3">
          <img src="asset/svg/icon-composer.svg" alt="">
        </div>
        <h5 class="text-center">PHP Composer</h5>
      </div>
      <div class="col-md-3">
        <div class="frame-image-center mb-3">
          <img src="asset/svg/icon-php-hosting-ioncube.svg" alt="">
        </div>
        <h5 class="text-center">PHP IonCube Loader</h5>
      </div>
    </div>
  </div>
</section>
<section class="mt-5 mb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h1>Paket Hosting Singapura yang Tepat</h1>
        <h3>Diskon 40% + Domain dan SSL Gratis Untuk Anda</h3>
      </div>
    </div>
    <?php 
      require_once('data.php');
      $data = json_decode($productJson);
    ?>
    <div class="row ps-2 pe-2">
      <?php 
      foreach($data as $product){
        $strDiscountPrice = currency_id($product->discount_price);
        $arrDiscountPrice = explode(".",$strDiscountPrice);
        $firstDigit = $arrDiscountPrice[0];
        unset($arrDiscountPrice[0]);
        $secondDigit = implode(".",$arrDiscountPrice);
        // print_r($arrDiscountPrice);
        $discountPrice = "Rp. <font class='first-price align-top'>".$firstDigit."</font>.<font class='align-top'>".$secondDigit."</font>";
      ?>
      <div class="col-md-3 ps-0 pe-0">
        <ul class="list-group">
          <li class="list-group-item text-center">
            <h3><?= Ucfirst($product->name) ?></h3>
          </li>
          <li class="list-group-item text-center">
            <h6><del>Rp. <?= currency_id($product->real_price) ?></del></h6>
            <div class="align-top">
            <?= $discountPrice ?>
            </div>
          </li>
          <li class="list-group-item text-center">
            <h6>
              <?= currency_id($product->user_count) ?> Pengguna Terdaftar
            </h6>
          </li>
          <li class="list-group-item text-center">
            <?php
            foreach($product->feature as $feature){
              echo '<p>'.(!empty($feature->value)?Ucfirst($feature->value):'').' '.UCwords($feature->feature_name).'</p>';
            }
            ?>
            <button type="button" class="btn btn-outline-dark">Pilih Sekarang</button>
          </li>

        </ul>
      </div>
      <?php } ?>
    </div>
  </div>
</section>
<section class="mt-5 pt-5 mb-5">
  <div class="container">
    <div class="row mb-5">
      <div class="col-md-12 text-center">
        <h2>Powerfull dengan Limit PHP yang Lebih Besar</h2>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-md-3">
        <ul class="list-group">
          <li class="list-group-item">
            <span class="align-middle">max execution time 300s</span>
          </li>
          <li class="list-group-item">
          <span class="align-middle">max execution time 300s</span>
          </li>
          <li class="list-group-item">
          <span class="align-middle">php memory limit 1024</span>
          </li>
        </ul>
      </div>
      <div class="col-md-3">
         <ul class="list-group">
           <li class="list-group-item">
           <span class="align-middle">post max size 128 MB</span>
            </li>
           <li class="list-group-item">
           <span class="align-middle">upload max filesize 128 MB</span>
           </li>
           <li class="list-group-item">
           <span class="align-middle">max input vars 2500</span>
           </li>
         </ul>   
      </div>
    </div>
  </div>
</section>
<section class="mt-5 mb-5">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
        <h2>Semua Paket Hosting Sudah Termasuk</h2>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-md-3 text-center">
        <img src="asset/svg/icon PHP Hosting_PHP Semua Versi.svg" alt="" width="50">
        <h6>PHP Semua Versi</h6>
        <span>Pilih mulai dari versi 5.3 s/d PHP 7.</span>
        <span>Ubah sesuka anda</span>
      </div>
      <div class="col-md-3 text-center">
        <img src="asset/svg/icon PHP Hosting_My SQL.svg" alt="" width="50">
        <h6>MySQL versi 5.6</h6>
        <span>Nikmati MySQL versi terbaru, tercepat dan kaya akan fitur</span>
      </div>
      <div class="col-md-3 text-center">
        <img src="asset/svg/icon PHP Hosting_CPanel.svg" alt="" width="50">
        <h6>Panel Hosting CPanel</h6>
        <span>Kelola website dengan panel canggih yang familiar di hati anda.</span>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-md-3 text-center">
        <img src="asset/svg/icon PHP Hosting_garansi uptime.svg" alt="" width="50">
        <h6>Garansi Uptime 99.9%</h6>
        <span>Datacenter yang mendukung kelangsungan website anda 24/7.</span>
      </div>
      <div class="col-md-3 text-center">
        <img src="asset/svg/icon PHP Hosting_InnoDB.svg" alt="" width="50">
        <h6>Database InnoDB Unlimited</h6>
        <span>Jumlah dan ukuran database yang tumbuh sesuai kebutuhan anda.</span>
      </div>
      <div class="col-md-3 text-center">
        <img src="asset/svg/icon PHP Hosting_My SQL remote.svg" alt="" width="50">
        <h6>Wildcard Remote MySQL</h6>
        <span>Mendukung s/d 25 max_user_connections dan 100 max_connections.</span>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 text-center">
        <h2>Mendukung penuh framework laravel</h2>
      </div>
    </div>
    <div class="row justify-content-center border-bottom">
      <div class="col-md-5">
        <span>Tak perlu menggunakan dedicated server atau VPS yang mahal.Layanan PHP hosting murah kami mendukung  penuh framework favorit Anda.</span>
        <ul>
          <li>Install <strong>1 klik</strong> dengan Softcolous installer.</li>
          <li>Mendukung extensi <strong>PHP MCript, phar, mbstring, json, </stong> dan <stong>fileinfo.</strong></li>
          <li>Tersedia <strong>Composer</strong> dan <strong>SSH</strong> untuk menginstall package pilihan anda</li>
        </ul>
        <span>Nb. Composer dan SSH hanya tersedia pada paket Personal dan Bisnis.</span>
      </div>
      <div class="col-md-5">
        <img src="asset/svg/illustration banner support laravel hosting.svg" alt="">
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 text-center">
        <h2>Modul lengkap untuk menjalankan aplikasi PHP anda.</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <ul>
          <li>Ice PHP</li>
          <li>apc</li>
          <li>ares</li>
          <li>bcmath</li>
          <li>bcompiler</li>
          <li>big_int</li>
          <li>bitset</li>
          <li>bloomy</li>
          <li>bz2_filter</li>
          <li>clamav</li>
          <li>coin_acceptor</li>
          <li>crack</li>
          <li>dba</li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>http</li>
          <li>huffman</li>
          <li>idn</li>
          <li>igbinary</li>
          <li>imagick</li>
          <li>imap</li>
          <li>inclued</li>
          <li>inotify</li>
          <li>interbase</li>
          <li>intl</li>
          <li>ioncube_loader</li>
          <li>ioncube_loader_4</li>
          <li>jsmin</li>
          <li>json</li>
          <li>ldap</li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>nd_pdo_mysql</li>
          <li>oauth</li>
          <li>oci8</li>
          <li>odbc</li>
          <li>opcache</li>
          <li>pdf</li>
          <li>pdo</li>
          <li>pdo_dblib</li>
          <li>pdo_firebird</li>
          <li>pdo_mysql</li>
          <li>pdo_odbc</li>
          <li>pdo_pgsql</li>
          <li>pdo_sqlite</li>
          <li>pgsql</li>
          <li>phalcon</li>
        </ul>
      </div>
      <div class="col-md-3">
        <ul>
          <li>stats</li>
          <li>stem</li>
          <li>stomp</li>
          <li>suhosin</li>
          <li>sybase_ct</li>
          <li>sysvmsg</li>
          <li>sysvsem</li>
          <li>sysvshm</li>
          <li>tidy</li>
          <li>timezonedb</li>
          <li>trader</li>
          <li>translit</li>
          <li>uploadprogress</li>
          <li>uri_template</li>
          <li>uuid</li>
        </ul>
      </div>
    </div>
    <div class="row mt-5">
      <div class="col-md-12 text-center">
      <button type="button" class="btn btn-outline-dark">Selengkapnya</button> 
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
            <h1>Linux Hosting yang Stabil dengan Teknologi LVE</h1>
            <span>
              SuperMicro <strong>Intel Xeon 24-Cores</strong> server dengan RAM <strong>128 GB</strong> dan teknologi <strong>LVE CloudLinux</strong> untuk stabilitas server Anda. Dilengkapi dengan <strong>SSD</strong> untuk kecepatan <strong>MySQL</strong> dan caching. Apache load balancer berbasis LiteSpeed Technologies, <strong>CageFS</strong> security, <strong>Raid-10</strong> protection dan auto backup untuk keamanan website PHP anda.
            </span>
      </div>
      <div class="col-md-6">
            <img src="asset/img/Image support.png" alt="">
      </div>
    </div>
  </div>

</section>
<section class="bg-light" >
  <div class="container">
    <div class="row pt-3 pb-3">
      <div class="col-md-6">Bagikan jika anda menyukai halaman ini</div>
    <div class="col-md-6"></div>
  </div>
</div>  

</section>
<section class="bg-primary pt-5 pb-5">
  <div class="container">
    <div class="col-md-12 ">
        <span>Perlu <strong>BANTUAN?</strong> Hubungi Kami: <strong>0274-5305505</strong></span>
    </div>
  </div>
</section>
<section>
  
</section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>    
  </body>
</html>